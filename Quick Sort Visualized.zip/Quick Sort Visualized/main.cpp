#include <iostream>
#include <windows.h>
#include <stdio.h>
#include <conio.h>

using namespace std;

void quicksort(int[],int,int);
int semisort(int[],int,int);
void coutcode (int);
void gotoxy(int,int);
void coutarray(int[],int,int,int);
int key = 0;

int main()
{
    int n[10];
    gotoxy(1,22);
    for (int i = 0; i<10; i++){
        n[i]= (rand()%89)+10;
        cout << n[i]<<" ";
    }
    quicksort(n,0,9);
    gotoxy(1,23);
    for (int i = 0; i<10; i++){
        cout << n[i]<<" ";
    }
    return 0;
}

void quicksort(int n[], int ibajo, int ialto){
    coutcode(1);
    coutcode(2);
    if (ibajo < ialto) {
        coutcode(3);
        int imedio = semisort(n, ibajo, ialto);
        coutcode(4);
        quicksort(n, ibajo, imedio-1);
        coutcode(4);
        coutcode(5);
        quicksort(n, imedio+1, ialto);
        coutcode(5);
        coutcode(6);
    }
    coutcode(7);
}

int semisort(int n[], int ibajo, int ialto){
    coutcode(8);
    coutcode(9);
    int p = n[ialto];
    coutarray(n,ialto,-1,-1);
    coutcode(10);
    int i = (ibajo-1);
    coutarray(n,ialto,i,-1);
    for (int j = ibajo; j <= ialto -1; j++){
        coutarray(n,ialto,i,j);
        coutcode(11);
        coutcode(12);
        if (n[j] <= p){
            coutcode(13);
            i++;
            coutarray(n,ialto,i,j);
            coutcode(14);
            swap(n[i],n[j]);
            coutarray(n,ialto,i,j);
            coutcode(15);
        }
        coutcode(16);
    }
    coutcode(17);
    coutarray(n,ialto,i+1,ialto);
    swap(n[i+1],n[ialto]);
    coutcode(17);
    coutarray(n,ialto,i+1,ialto);
    coutcode(18);
    coutcode(19);
    return (i+1);
}

void Change(int color){
    HANDLE hConsole;
    hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, color);
}

void checkcolor (bool executing){
    if (executing){
        Change(143);
    } else {
        Change(15);
    }
}
void coutarray(int n[],int p, int a, int b){
    gotoxy(70,5);
    Change(15);
    for (int i = 0; i<10; i++){
        if (b ==i)
            Change(79);
        if (a ==i)
            Change(63);
        if (p ==i)
            Change(31);
        cout << n[i]<<" ";
        Change(15);
    }
    gotoxy(70,6);
    for (int i = 0; i<10; i++){
        if (b ==i)
            Change(79);
        if (a ==i)
            Change(63);
        if (p ==i)
            Change(31);
        cout <<"   ";
        Change(15);
    }
    gotoxy(70,7);
    for (int i = 0; i<10; i++){
        if (b ==i)
            Change(79);
        if (a ==i)
            Change(63);
        cout <<"   ";
        Change(15);
    }
    gotoxy(70,8);
    for (int i = 0; i<10; i++){
        if (b ==i)
            Change(79);
        cout <<"   ";
        Change(15);
    }
}
void coutcode(int executing){
    gotoxy(1,1);
    checkcolor(executing==1);cout <<"void quicksort(int n[], int ibajo, int ialto){"<<endl;
    checkcolor(executing==2);cout <<"    if (ibajo < ialto) {"<<endl;
    checkcolor(executing==3);cout <<"        int imedio = semisort(n, ibajo, ialto);"<<endl;
    checkcolor(executing==4);cout <<"        quicksort(n, ibajo, imedio-1);"<<endl;
    checkcolor(executing==5);cout <<"        quicksort(n, imedio+1, ialto);"<<endl;
    checkcolor(executing==6);cout <<"    }"<<endl;
    checkcolor(executing==7);cout <<"}"<<endl;
    checkcolor(executing==8);cout <<"int semisort(int n[], int ibajo, int ialto){"<<endl;
    checkcolor(executing==9);cout <<"    int p = n[ialto];"<<endl;
    checkcolor(executing==10);cout <<"    int i = (ibajo-1);"<<endl;
    checkcolor(executing==11);cout <<"    for (int j = ibajo; j <= ialto -1; j++){"<<endl;
    checkcolor(executing==12);cout <<"        if (n[j] <= p){"<<endl;
    checkcolor(executing==13);cout <<"            i++;"<<endl;
    checkcolor(executing==14);cout <<"            swap(n[i],n[j]);"<<endl;
    checkcolor(executing==15);cout <<"        }"<<endl;
    checkcolor(executing==16);cout <<"    }"<<endl;
    checkcolor(executing==17);cout <<"    swap(n[i+1],n[ialto]);"<<endl;
    checkcolor(executing==18);cout <<"    return (i+1);"<<endl;
    checkcolor(executing==19);cout <<"}"<<endl;
    if (key!=8){
    key = getch();
    }else{
    Sleep(100);
    }
}
void gotoxy (int cx, int cy) {
    HANDLE hCon;
    hCon = GetStdHandle(STD_OUTPUT_HANDLE);

    COORD Anita;
    Anita.X=cx-1;
    Anita.Y=cy-1;
    SetConsoleCursorPosition(hCon, Anita);
}
